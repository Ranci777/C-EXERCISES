#include <stdio.h>
#include <stdlib.h>

int ehQuadradoMagico(int **matriz, int n);

int main() {
    int n;
    printf("Digite a ordem da matriz quadrada: ");
    scanf("%d", &n);

    // Alocar matriz dinamicamente
    int **matriz = malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++)
        matriz[i] = malloc(n * sizeof(int));

    printf("Digite os elementos da matriz %d x %d:\n", n, n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &matriz[i][j]);

    if (ehQuadradoMagico(matriz, n)) {
        printf("A matriz é um quadrado mágico.\n");
    } else {
        printf("A matriz NÃO é um quadrado mágico.\n");
    }

    // Liberar memória
    for (int i = 0; i < n; i++)
        free(matriz[i]);
    free(matriz);

    return 0;
}

int ehQuadradoMagico(int **matriz, int n) {
    int somaReferencia = 0;
    // Soma da primeira linha para referência
    for (int j = 0; j < n; j++)
        somaReferencia += matriz[0][j];

    // Verificar soma das outras linhas
    for (int i = 1; i < n; i++) {
        int somaLinha = 0;
        for (int j = 0; j < n; j++)
            somaLinha += matriz[i][j];
        if (somaLinha != somaReferencia)
            return 0; // Não é quadrado mágico
    }

    // Verificar soma das colunas
    for (int j = 0; j < n; j++) {
        int somaColuna = 0;
        for (int i = 0; i < n; i++)
            somaColuna += matriz[i][j];
        if (somaColuna != somaReferencia)
            return 0;
    }

    // Soma diagonal principal
    int somaDiagPrincipal = 0;
    for (int i = 0; i < n; i++)
        somaDiagPrincipal += matriz[i][i];
    if (somaDiagPrincipal != somaReferencia)
        return 0;

    // Soma diagonal secundária
    int somaDiagSecundaria = 0;
    for (int i = 0; i < n; i++)
        somaDiagSecundaria += matriz[i][n - 1 - i];
    if (somaDiagSecundaria != somaReferencia)
        return 0;

    return 1; // É quadrado mágico
}
