#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define L 5
#define C 7

// Funções para o exercício 1
void preencherMatrizAleatoriaEx1(int matriz[L][C]);
void imprimirMatrizEx1(int matriz[L][C]);
void imprimirTranspostaEx1(int matriz[L][C]);

// Funções para o exercício 2
void gerarMatrizTriangularInferiorEx2(int matriz[N][N]);
void imprimirMatrizTriangularInferiorEx2(int matriz[N][N]);

// Verifica se um vetor de tamanho n é uma permutação dos números de 1 a n
int ehPermutacao(int vetor[], int n);

// Verifica se uma matriz é um quadrado latino
int ehQuadradoLatino(int matriz[N][N], int n);

int main() {
    srand(time(NULL));

    printf("Exercicio 1:\n");
    int matriz1[L][C];
    preencherMatrizAleatoriaEx1(matriz1);
    imprimirMatrizEx1(matriz1);
    printf("Transposta:\n");
    imprimirTranspostaEx1(matriz1);

    printf("\nExercicio 2:\n");
    int matriz2[N][N];
    gerarMatrizTriangularInferiorEx2(matriz2);
    imprimirMatrizTriangularInferiorEx2(matriz2);

    return 0;
}

void preencherMatrizAleatoriaEx1(int matriz[L][C]) {
    for (int i = 0; i < L; i++)
        for (int j = 0; j < C; j++)
            matriz[i][j] = rand() % 26;  // de 0 a 25
}

void imprimirMatrizEx1(int matriz[L][C]) {
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < C; j++)
            printf("%3d ", matriz[i][j]);
        printf("\n");
    }
}

void imprimirTranspostaEx1(int matriz[L][C]) {
    for (int j = 0; j < C; j++) {
        for (int i = 0; i < L; i++)
            printf("%3d ", matriz[i][j]);
        printf("\n");
    }
}

void gerarMatrizTriangularInferiorEx2(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++)
            matriz[i][j] = rand() % 16 + 10;  // de 10 a 25
        for (int j = i + 1; j < N; j++)
            matriz[i][j] = 0;
    }
}

void imprimirMatrizTriangularInferiorEx2(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++)
            printf("%3d ", matriz[i][j]);
        printf("\n");
    }
}

int ehPermutacao(int vetor[], int n) {
    int presente[N + 1] = {0};
    int valido = 1;

    for (int i = 0; i < n; i++) {
        int valor = vetor[i];
        if (valor < 1 || valor > n || presente[valor]) {
            valido = 0;
            break;
        }
        presente[valor] = 1;
    }

    return valido;
}

int ehQuadradoLatino(int matriz[N][N], int n) {
    int temp[N];
    int valido = 1;

    // Verifica linhas
    for (int i = 0; i < n && valido; i++) {
        for (int j = 0; j < n; j++)
            temp[j] = matriz[i][j];
        if (!ehPermutacao(temp, n))
            valido = 0;
    }

    // Verifica colunas
    for (int j = 0; j < n && valido; j++) {
        for (int i = 0; i < n; i++)
            temp[i] = matriz[i][j];
        if (!ehPermutacao(temp, n))
            valido = 0;
    }

    return valido;
}
