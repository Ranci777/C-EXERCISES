#include <stdio.h>

#define N 6

void gerarTrianguloPascal(int matriz[N][N]);
void imprimirTrianguloPascal(int matriz[N][N]);

int main() {
    int matriz[N][N] = {0};

    gerarTrianguloPascal(matriz);
    printf("Triangulo de Pascal com %d linhas:\n", N);
    imprimirTrianguloPascal(matriz);

    return 0;
}

void gerarTrianguloPascal(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        matriz[i][0] = 1;
        for (int j = 1; j <= i; j++) {
            if (j == i)
                matriz[i][j] = 1;
            else
                matriz[i][j] = matriz[i - 1][j - 1] + matriz[i - 1][j];
        }
    }
}

void imprimirTrianguloPascal(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%4d", matriz[i][j]);
        }
        printf("\n");
    }
}

