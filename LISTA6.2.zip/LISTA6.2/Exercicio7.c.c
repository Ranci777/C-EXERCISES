#include <stdio.h>
#include <stdbool.h>

#define TAM 10

// Protótipos
void criarMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool *criadas);
void imprimirMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas);
void somarMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas);
void subtrairMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas);
void multiplicarConstanteESomar(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas);

int main() {
    int opcao;
    int matriz1[TAM][TAM], matriz2[TAM][TAM];
    bool matrizesCriadas = false;

    do {
        printf("\nMenu de opções:\n");
        printf("0 - Criar duas matrizes 10x10\n");
        printf("1 - Imprimir as matrizes originais\n");
        printf("2 - Somar as duas matrizes e imprimir o resultado\n");
        printf("3 - Subtrair a primeira da segunda e imprimir o resultado\n");
        printf("4 - Multiplicar uma constante à primeira matriz, somar à segunda e imprimir o resultado\n");
        printf("9 - Sair\n");
        printf("Digite a opção desejada: ");
        scanf("%d", &opcao);

        if (opcao == 0) {
            criarMatrizes(matriz1, matriz2, &matrizesCriadas);
        } else if (opcao == 1) {
            imprimirMatrizes(matriz1, matriz2, matrizesCriadas);
        } else if (opcao == 2) {
            somarMatrizes(matriz1, matriz2, matrizesCriadas);
        } else if (opcao == 3) {
            subtrairMatrizes(matriz1, matriz2, matrizesCriadas);
        } else if (opcao == 4) {
            multiplicarConstanteESomar(matriz1, matriz2, matrizesCriadas);
        } else if (opcao == 9) {
            printf("Encerrando o programa.\n");
        } else {
            printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 9);

    return 0;
}

// Funções

void criarMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool *criadas) {
    printf("Preenchendo matriz 1:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("M1[%d][%d]: ", i, j);
            scanf("%d", &m1[i][j]);
        }
    }

    printf("Preenchendo matriz 2:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("M2[%d][%d]: ", i, j);
            scanf("%d", &m2[i][j]);
        }
    }

    *criadas = true;
    printf("Matrizes criadas com sucesso.\n");
}

void imprimirMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas) {
    if (!criadas) {
        printf("As matrizes ainda não foram criadas.\n");
        return;
    }

    printf("Matriz 1:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("%4d", m1[i][j]);
        }
        printf("\n");
    }

    printf("Matriz 2:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("%4d", m2[i][j]);
        }
        printf("\n");
    }
}

void somarMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas) {
    if (!criadas) {
        printf("As matrizes ainda não foram criadas.\n");
        return;
    }

    printf("Soma das matrizes:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("%4d", m1[i][j] + m2[i][j]);
        }
        printf("\n");
    }
}

void subtrairMatrizes(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas) {
    if (!criadas) {
        printf("As matrizes ainda não foram criadas.\n");
        return;
    }

    printf("Subtração (M2 - M1):\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("%4d", m2[i][j] - m1[i][j]);
        }
        printf("\n");
    }
}

void multiplicarConstanteESomar(int m1[TAM][TAM], int m2[TAM][TAM], bool criadas) {
    if (!criadas) {
        printf("As matrizes ainda não foram criadas.\n");
        return;
    }

    int constante;
    printf("Digite a constante para multiplicar a matriz 1: ");
    scanf("%d", &constante);

    printf("Resultado de (constante * M1) + M2:\n");
    for (int i = 0; i < TAM; i++) {
        for (int j = 0; j < TAM; j++) {
            printf("%4d", (constante * m1[i][j]) + m2[i][j]);
        }
        printf("\n");
    }
}
