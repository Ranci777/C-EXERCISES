#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ALUNOS 5
#define QUESTOES 10

void lerGabarito(int gabarito[QUESTOES]);
void gerarRespostasAlunos(int respostas[ALUNOS][QUESTOES]);
void corrigirRespostas(int respostas[ALUNOS][QUESTOES], int gabarito[QUESTOES], int resultado[ALUNOS]);
void imprimirRespostas(int respostas[ALUNOS][QUESTOES]);
void imprimirResultado(int resultado[ALUNOS]);
void imprimirGabarito(int gabarito[QUESTOES]);

int main() {
    int gabarito[QUESTOES];
    int respostas[ALUNOS][QUESTOES];
    int resultado[ALUNOS];

    srand(time(NULL));

    lerGabarito(gabarito);
    gerarRespostasAlunos(respostas);
    corrigirRespostas(respostas, gabarito, resultado);

    printf("\nGabarito:\n");
    imprimirGabarito(gabarito);

    printf("\nRespostas dos alunos:\n");
    imprimirRespostas(respostas);

    printf("\nPontuacao dos alunos:\n");
    imprimirResultado(resultado);

    return 0;
}

void lerGabarito(int gabarito[QUESTOES]) {
    printf("Digite o gabarito para as %d questoes (valores: 10, 20, 30 ou 40):\n", QUESTOES);
    for (int i = 0; i < QUESTOES; i++) {
        int valido = 0;
        while (!valido) {
            printf("Questao %d: ", i + 1);
            scanf("%d", &gabarito[i]);
            if (gabarito[i] == 10 || gabarito[i] == 20 || gabarito[i] == 30 || gabarito[i] == 40) {
                valido = 1;
            } else {
                printf("Valor invalido! Digite 10, 20, 30 ou 40.\n");
            }
        }
    }
}

void gerarRespostasAlunos(int respostas[ALUNOS][QUESTOES]) {
    int opcoes[4] = {10, 20, 30, 40};
    for (int i = 0; i < ALUNOS; i++) {
        for (int j = 0; j < QUESTOES; j++) {
            respostas[i][j] = opcoes[rand() % 4];
        }
    }
}

void corrigirRespostas(int respostas[ALUNOS][QUESTOES], int gabarito[QUESTOES], int resultado[ALUNOS]) {
    for (int i = 0; i < ALUNOS; i++) {
        resultado[i] = 0;
        for (int j = 0; j < QUESTOES; j++) {
            if (respostas[i][j] == gabarito[j]) {
                resultado[i]++;
            }
        }
    }
}

void imprimirRespostas(int respostas[ALUNOS][QUESTOES]) {
    for (int i = 0; i < ALUNOS; i++) {
        printf("Aluno %d: ", i + 1);
        for (int j = 0; j < QUESTOES; j++) {
            printf("%2d ", respostas[i][j]);
        }
        printf("\n");
    }
}

void imprimirResultado(int resultado[ALUNOS]) {
    for (int i = 0; i < ALUNOS; i++) {
        printf("Aluno %d: %d acertos\n", i + 1, resultado[i]);
    }
}

void imprimirGabarito(int gabarito[QUESTOES]) {
    printf("Gabarito: ");
    for (int i = 0; i < QUESTOES; i++) {
        printf("%2d ", gabarito[i]);
    }
    printf("\n");
}



