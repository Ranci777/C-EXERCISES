#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 10

void gerarMatrizAleatoria(int matriz[N][N]);
void imprimirMatriz(int matriz[N][N]);
void encontrarMaiorEMinimax(int matriz[N][N], int *maior, int *linhaMaior, int *minimax, int *MiMAX);

int main() {
    int matriz[N][N];
    int maior, linhaMaior, minimax, MiMAX;

    srand(time(NULL));

    gerarMatrizAleatoria(matriz);

    printf("Matriz gerada:\n");
    imprimirMatriz(matriz);

    encontrarMaiorEMinimax(matriz, &maior, &linhaMaior, &minimax, &MiMAX);

    printf("\nMaior elemento: %d, encontrado na linha %d\n", maior, linhaMaior);
    printf("Elemento minimax (menor da linha %d): %d, coluna %d\n", linhaMaior, minimax, MiMAX);

    return 0;
}

void gerarMatrizAleatoria(int matriz[N][N]) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            matriz[i][j] = rand() % 100;  // valores de 0 a 99
}

void imprimirMatriz(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%3d ", matriz[i][j]);
        }
        printf("\n");
    }
}

void encontrarMaiorEMinimax(int matriz[N][N], int *maior, int *linhaMaior, int *minimax, int *MiMAX) {
    *maior = matriz[0][0];
    *linhaMaior = 0;

    // Encontra maior elemento e linha
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (matriz[i][j] > *maior) {
                *maior = matriz[i][j];
                *linhaMaior = i;
            }
        }
    }

    // Encontra minimax: menor elemento da linha do maior
    *minimax = matriz[*linhaMaior][0];
    *MiMAX = 0;
    for (int j = 1; j < N; j++) {
        if (matriz[*linhaMaior][j] < *minimax) {
            *minimax = matriz[*linhaMaior][j];
            *MiMAX = j;
        }
    }
}
