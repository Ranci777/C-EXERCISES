#include <stdio.h>

#define MAX 100

int ehPermutacao(int vetor[], int n);
int ehQuadradoLatino(int matriz[MAX][MAX], int n);

int main() {
    int n;
    int matriz[MAX][MAX];

    printf("Digite a ordem da matriz (n x n): ");
    scanf("%d", &n);

    printf("Digite os elementos da matriz:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &matriz[i][j]);

    if (ehQuadradoLatino(matriz, n)) {
        printf("A matriz É um quadrado latino.\n");
    } else {
        printf("A matriz NÃO é um quadrado latino.\n");
    }

    return 0;
}

// Verifica se um vetor é permutação dos números de 1 a n
int ehPermutacao(int vetor[], int n) {
    int marca[MAX] = {0};
    int valido = 1;

    for (int i = 0; i < n && valido; i++) {
        int valor = vetor[i];
        if (valor < 1 || valor > n || marca[valor]) {
            valido = 0;
        } else {
            marca[valor] = 1;
        }
    }

    return valido;
}

// Verifica se a matriz é um quadrado latino
int ehQuadradoLatino(int matriz[MAX][MAX], int n) {
    int temp[MAX];
    int valido = 1;

    // Verifica linhas
    for (int i = 0; i < n && valido; i++) {
        for (int j = 0; j < n; j++)
            temp[j] = matriz[i][j];

        if (!ehPermutacao(temp, n))
            valido = 0;
    }

    // Verifica colunas
    for (int j = 0; j < n && valido; j++) {
        for (int i = 0; i < n; i++)
            temp[i] = matriz[i][j];

        if (!ehPermutacao(temp, n))
            valido = 0;
    }

    return valido;
}



