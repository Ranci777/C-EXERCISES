#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 4  // Pode alterar aqui para qualquer ordem desejada

void gerarMatriz(int matriz[N][N]);
void imprimirMatriz(int matriz[N][N]);
void multiplicarMatrizes(int A[N][N], int B[N][N], int resultado[N][N]);
void copiarMatriz(int origem[N][N], int destino[N][N]);

int main() {
    srand(time(NULL));

    int A[N][N];
    int resultado[N][N];
    int potencia[N][N];

    // Gerar matriz aleatória
    gerarMatriz(A);

    printf("Matriz A:\n");
    imprimirMatriz(A);

    // A^2 = A * A
    multiplicarMatrizes(A, A, resultado);
    printf("\nA^2:\n");
    imprimirMatriz(resultado);

    // A^3 = A^2 * A
    multiplicarMatrizes(resultado, A, potencia);
    printf("\nA^3:\n");
    imprimirMatriz(potencia);

    // A^4 = A^3 * A
    multiplicarMatrizes(potencia, A, resultado);
    printf("\nA^4:\n");
    imprimirMatriz(resultado);

    return 0;
}

void gerarMatriz(int matriz[N][N]) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            matriz[i][j] = rand() % 10;  // valores 0 a 9
}

void imprimirMatriz(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            printf("%3d ", matriz[i][j]);
        printf("\n");
    }
}

void multiplicarMatrizes(int A[N][N], int B[N][N], int resultado[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            resultado[i][j] = 0;
            for (int k = 0; k < N; k++)
                resultado[i][j] += A[i][k] * B[k][j];
        }
    }
}

void copiarMatriz(int origem[N][N], int destino[N][N]) {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            destino[i][j] = origem[i][j];
}
