#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Função para gerar matriz aleatória
void gerarMatriz(int L, int C, int matriz[L][C]) {
    for (int i = 0; i < L; i++)
        for (int j = 0; j < C; j++)
            matriz[i][j] = rand() % 10;  // valores de 0 a 9
}

// Função para imprimir matriz
void imprimirMatriz(int L, int C, int matriz[L][C]) {
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < C; j++) {
            printf("%3d ", matriz[i][j]);
        }
        printf("\n");
    }
}

// Função para multiplicar matrizes A (L1xC1) e B (L2xC2)
// resultado será matriz L1xC2
void multiplicarMatrizes(int L1, int C1, int A[L1][C1], int L2, int C2, int B[L2][C2], int resultado[L1][C2]) {
    // Verifica se pode multiplicar
    if (C1 != L2) {
        printf("Erro: matrizes com dimensoes invalidas para multiplicacao.\n");
        return;
    }

    for (int i = 0; i < L1; i++) {
        for (int j = 0; j < C2; j++) {
            resultado[i][j] = 0;
            for (int k = 0; k < C1; k++) {
                resultado[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

int main() {
    srand(time(NULL));

    int L1 = 5, C1 = 6;
    int L2 = 6, C2 = 5;

    int A[L1][C1];
    int B[L2][C2];
    int resultado[L1][C2];

    gerarMatriz(L1, C1, A);
    gerarMatriz(L2, C2, B);

    printf("Matriz A (%dx%d):\n", L1, C1);
    imprimirMatriz(L1, C1, A);

    printf("\nMatriz B (%dx%d):\n", L2, C2);
    imprimirMatriz(L2, C2, B);

    multiplicarMatrizes(L1, C1, A, L2, C2, B, resultado);

    printf("\nResultado da multiplicacao A x B (%dx%d):\n", L1, C2);
    imprimirMatriz(L1, C2, resultado);

    return 0;
}
