#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 6

// Protótipos
void gerarMatrizTriangularInferior(int matriz[N][N]);
void imprimirMatrizTriangularInferior(int matriz[N][N]);

int main() {
    int matriz[N][N];

    srand(time(NULL)); // Inicializa gerador de números aleatórios

    gerarMatrizTriangularInferior(matriz);

    printf("Matriz triangular inferior de ordem %d:\n", N);
    imprimirMatrizTriangularInferior(matriz);

    return 0;
}

// Preenche a parte triangular inferior com valores entre 10 e 25
void gerarMatrizTriangularInferior(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++) {
            matriz[i][j] = rand() % 16 + 10; // 10 a 25
        }
        for (int j = i + 1; j < N; j++) {
            matriz[i][j] = 0; // parte superior da matriz
        }
    }
}

// Imprime apenas os elementos preenchidos da matriz triangular inferior
void imprimirMatrizTriangularInferior(int matriz[N][N]) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j <= i; j++) {
            printf("%3d ", matriz[i][j]);
        }
        printf("\n");
    }
}
